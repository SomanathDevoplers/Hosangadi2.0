hours= 15
//const now = new Date('2022/04/18 09:30:00 PM');
const now = new Date();
minutes = 30
let timediff = Math.floor(Math.floor((new Date(now.getFullYear() + '/' + String(now.getMonth() + 1).padStart(2, '0') + '/' +String(now.getDate()).padStart(2, '0')+' '+hours+':'+minutes+':00').getTime() - now) / 1000) / 60)
if(timediff<0)
timediff =  (-1 * timediff).toFixed(0)
console.log(timediff);
if(timediff>720)
    timediff = timediff-720
console.log(timediff);
/*
if(timediff<0){
var nextDay = new Date(now);
nextDay.setDate(now.getDate() + 1);
const timediff = Math.floor(Math.floor( 
    (new Date('2022/04/18 8:00:00 PM') - new Date(now.getFullYear() + '/' + String(now.getMonth() + 1).padStart(2, '0') + '/' +String(now.getDate()).padStart(2, '0')+' '+hours+':'+minutes+':00 AM').getTime() ) / 1000) / 60)
console.log(timediff);
}
*/