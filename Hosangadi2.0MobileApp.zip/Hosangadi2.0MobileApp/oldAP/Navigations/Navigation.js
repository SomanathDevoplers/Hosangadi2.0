import React from 'react';
import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from "react-navigation";
import Login from '../Screens/Login';
import Menu from '../Screens/Menu';
import SalesBill from '../Screens/SalesBill'

const MainNavigator = createStackNavigator({
    LoginFrom : Login,
    Menu      : Menu ,
    SalesBill : {
        screen : SalesBill,
        navigationOptions:{
            title : "Sales Bill",
            headerLeft: ()=> null
        }
    }
    },{
    headerStyle : {
        backgroundColor : '#C2185B'
    },
    headerTitleStyle:{
        fontWeight : 'bold',
    },
        headerTintColor : 'white'
    }
)

export default createAppContainer(MainNavigator);