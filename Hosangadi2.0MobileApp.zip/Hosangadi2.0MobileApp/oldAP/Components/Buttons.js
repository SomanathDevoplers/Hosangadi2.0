import React from 'react';
import {TouchableNativeFeedback,View, Text,StyleSheet,} from 'react-native'


const Buttons = props => {
return(
    <TouchableNativeFeedback onPressIn={props.Press} onLongPress={props.longPress}>
        <View style = {{...styles.buttonContainer,...props.buttonStyle}}>
            <Text style = {props.textStyle}>{props.children}</Text>
        </View>
    </TouchableNativeFeedback>
    )
}

const styles = StyleSheet.create({
buttonContainer:{
    backgroundColor : '#8EDFA2',
    borderRadius : 5,
    alignContent : 'center',
    justifyContent : 'center',
    padding: 5,
}
})
export default Buttons;