import React,{ useState,useEffect } from 'react';
import {View, Text,TextInput, StyleSheet,FlatList,TouchableOpacity,KeyboardAvoidingView} from 'react-native'
import {  useSelector } from "react-redux";
import ProductEntry from './ProductEntry';


const CustomerName = props =>{
    const [state,setState] = useState({
        text : '',
        accId : 0,
        namelist : [],
        bool : true
    })
    const { text , accId , namelist, bool} = state

    const allCustomer = useSelector(state => state.customerName.customerName)
    
    useEffect(() => {
      getCutomerName()
      }, [bool])
    
    const getCutomerName =  () => {
        
            let filtered = [];
            let toSearch = text.toUpperCase();
            if(toSearch.trim().length == 0) toSearch = null
            for(let i=0; i < allCustomer.length; i++) 
            {
            for(var key in allCustomer[i]) ;
            {
                if(String(allCustomer[i][key]).indexOf(toSearch)!= -1) 
                {
                filtered.push(allCustomer[i]);
                }
            }
            }
            setState({    
            text : text,
            accId : accId,
            namelist : filtered,
            bool : bool,
            })
        
      }
    
    const renderItem = ({ item }) => (
        <Item title={item.acc_name} id = {item.acc_id}/>
      );
    

    const Item = ({ title,id }) => (      
        <TouchableOpacity 
        onPress={()=>setState({
            text : title,
            accId : id,
            namelist : [],
            bool : bool,
            })} 
        style={styles.item}>
         <Text style={styles.title}>{title}</Text>
        </TouchableOpacity>
        )
    
      return( 
      
        <View style = {styles.screen}>

            <View style = {styles.cutomerDetails}>
                <TextInput
                placeholder='Cutomer Name'
                style = {styles.customerName}
                
                onChangeText = { x => setState({
                    text : x,
                    accId : 0,
                    namelist : namelist,
                    bool : !bool,
                })}

                value = {text}
                />
            </View>

            {namelist.length == 0 ? (
            <View style ={styles.entryData} >       
            <ProductEntry accId = {accId}/>
            </View>
            ) : (

            <FlatList
            style = {styles.flatlist}
            data = {namelist}
            renderItem= {renderItem}
            keyExtractor= {item => item.acc_id}
            />

        )}
        
        
        </View>

        )
}

const styles = StyleSheet.create({
    screen : {
        height:'100%',
        alignItems: 'center',
    },
    cutomerDetails : {
        height : '10%',
        padding:2,
        marginTop : 10,
        marginBottom : 5,
        alignContent: 'center',
        alignItems: 'center',
        width: '70%',
        backgroundColor : 'black',
        shadowColor : 'black',
        shadowOffset : {width: 0 ,height :2},
        shadowOpacity : 0.26,
        shadowRadius: 8,
        elevation : 5,
        borderRadius :10,
    },
    customerName : {
        paddingLeft : 10,
        width :'100%',
        height:'100%',
        borderColor : 'black',
        backgroundColor: 'white',
        borderWidth : 2,
        fontSize : 20,
        borderRadius :10,
    },
    item: {
        backgroundColor: '#f9c2ff',
        padding: 20,
       
        marginVertical: 8,
        marginHorizontal: 0,
    },
    title: {
        fontSize: 16,
    },
    flatlist:{
        width: "80%",
    },
    entryData : {
          flex : 1,
          marginVertical : 5,
    },
    
})

export default CustomerName;