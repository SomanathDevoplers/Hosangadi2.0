import React,{ useState,useEffect} from 'react';
import {View, Text,TextInput, StyleSheet, FlatList, TouchableOpacity,Alert} from 'react-native'
import Buttons from './Buttons';

const ProductEntry = props =>{

    let boolEnableInput = props.accId == 0 ? false : true
    const [custType, setCustType] = useState('NML')
    const [nameText, setNameText] = useState('')
    const [qtyState, setQtyState] = useState({
        qtyText : '',
        Total : 0,
        spText : ''
    })

    const [state , setState] = useState({
        prodNameList : [],
        showFlatlist : false,
        enableInput : boolEnableInput,
        qtySuggValues : [1.000,1.000,1.000,1.000],
        tax_ids : [-1,-1],
        prod_id : -1,
        prod_unit : 'N',
        spListArray : [0,0,0],
        maxQty : 9999
    })
    const {qtyText,Total,spText}= qtyState
    const {prodNameList, showFlatlist, enableInput, qtySuggValues,prod_id,prod_unit,spListArray,maxQty} = state

   
    const getCutomerType = async(accId) =>{
        try {

            const response = await fetch(`http://192.168.1.34:6000/onlySql?sql=SELECT acc_cus_type FROM somanath.accounts where acc_id =${accId}`);
            let custType = await response.json() 
            if(custType.length !=  0){
                setCustType(custType[0].acc_cus_type)
            }
            }
            catch(e){
                console.log(e)
            }
    }
    
    useEffect(() => {
        getCutomerType(props.accId)
        }, [boolEnableInput])
    
    const getQty = e =>{
        calTotalQty(e)
    }

    const productSearch = async (textInp)=>{
        setNameText(textInp)
        if (textInp.length > 2){
            
            try {
                const response = await fetch(`http://192.168.1.34:4000/getNameFew?prod_name=${textInp.toUpperCase()}`);
                let prodList = await response.json()
                let list = []
                let i = 0
                prodList.forEach(element => {
                let prodListObject = {}
                i++
                prodListObject.id = i
                prodListObject.name = element
                list.push(prodListObject)
                });

                setState({
                    text : textInp,
                    prodNameList : list, 
                    showFlatlist : list.length != 0?true:false,
                    enableInput : boolEnableInput,
                    qtySuggValues : qtySuggValues,
                    tax_ids : [-1,-1],
                    prod_id : -1,
                    prod_unit : 'N',
                    spListArray : [0,0,0],
                    maxQty : 9999
                });
            }
            catch(e){
                console.log(e)
            }
        }
        else if(textInp.length == 0){
            
            setState({
                prodNameList : [],
                showFlatlist : false,
                enableInput : boolEnableInput,
                qtySuggValues : qtySuggValues,
                tax_ids : [-1,-1],
                prod_id : -1,
                prod_unit : 'N',
                spListArray : [0,0,0],
                maxQty : 9999
                
            });
        }    
    }

    const getProdDetails = async(prodName) =>{
        setNameText(prodName)
        try {
            const response = await fetch(`http://192.168.1.34:4000/getProdByName?prod_name=${prodName}`);
            let prodDetails = await response.json()  
            
            
            //@Year = '21' should be changed to dynamic
            let dbYear = 21
            let prodId = prodDetails[0].prod_id
            const response1 = await fetch(`http://192.168.1.34:6000/onlySql?sql=SELECT stk_tot_qty,stk_sp_nml,somanath.products.prod_unit_type FROM somanath20${dbYear}.stocks , somanath.products where stk_prod_id = ${prodId} and stk_prod_qty > 0 and somanath.products.prod_id = somanath20${dbYear}.stocks.stk_prod_id  order  by somanath20${dbYear}.stocks.insert_time limit 1 ;`);
            let stockDetails = await response1.json() 
            
            let qtySug = qtySuggValues
            let spList = spListArray
            switch(custType){
                case 'NML':
                    qtySug = prodDetails[0].nml_unit.split(':').slice(1,-1)
                    spList = stockDetails[0].stk_sp_nml.split(':').slice(1,-1)
                    break
                case 'HTL':
                    qtySug = prodDetails[0].htl_unit.split(':').slice(1,-1)
                    spList = stockDetails[0].stk_sp_htl.split(':').slice(1,-1)
                    break
                case 'ANG':
                    qtySug = prodDetails[0].ang_unit.split(':').slice(1,-1)
                    spList = stockDetails[0].stk_sp_ang.split(':').slice(1,-1)
                    break
                case 'SPL':
                    qtySug = prodDetails[0].spl_unit.split(':').slice(1,-1)
                    spList = stockDetails[0].stk_sp_spl.split(':').slice(1,-1)
                    break
            }
          
            setState({
                prodNameList : [],
                showFlatlist : false,
                enableInput : boolEnableInput,
                qtySuggValues : qtySug,
                tax_ids : [prodDetails[0].prod_gst,prodDetails[0].prod_cess],
                prod_id : prodDetails[0].prod_id,
                prod_unit : stockDetails[0].prod_unit_type,
                spListArray : spList,
                maxQty : stockDetails[0].stk_tot_qty
            });

            
        }
        catch(e){
            console.log(e)
        }
    }

    const calTotalQty= (qtyv) => {
        let qty = parseFloat(qtyv)
        if(Number.isNaN(spText) || Number.isNaN(qty)){
            qty = 0
        }
        if (qty>maxQty){
            Alert.alert("ಹೋಯಿ", `Stock ಇಪ್ಪ್ದೇ ${maxQty.toFixed(3)}${prod_unit}`)
            setQtyState({
                qtyText: '',
                Total : 0,
                spText : ''
            })
            
        }else{
            let total = 0
            let sp = 0
            if( qty >= parseFloat(qtySuggValues[3]) ){
                sp = parseFloat(spListArray[3])
                total = sp * qty
            }
            else if(qty>=parseFloat(qtySuggValues[2])){
                sp = parseFloat(spListArray[2])
                total = sp * qty
            }
            else if(qty>=parseFloat(qtySuggValues[1])){
                sp = parseFloat(spListArray[1])
                total = sp * qty
            }
            else{
                sp = parseFloat(spListArray[0])
                total = sp * qty
            }
            if(Number.isNaN(spText) || Number.isNaN(parseFloat(qtyv))){
                qty = ''
            }
            setQtyState({
                qtyText: String(qty),
                Total : total.toFixed(2),
                spText : sp.toFixed(2)
            })
        }
       
    }
    
    const calTotalSp = (sp) =>{
        sp = parseFloat(sp)
        let qty = qtyText
        if(Number.isNaN(sp) || Number.isNaN(qtyText)){
            qty = ''; sp = 0
        }
        setQtyState({
            qtyText: qty,
            Total : (qty*sp).toFixed(2),
            spText : sp
        })
    }

    const renderItem = ({ item }) => (
        <Item title={item.name} id = {item.id}/>
    );

    const Item = ({ title }) => (
        
        <TouchableOpacity 
        onPress={()=>
            getProdDetails(title)
            } 
        
        style={styles.item}>
        <Text style={styles.title}>{title}</Text>
        </TouchableOpacity>
        )
    
    
return(
        <View style = {styles.entryScreen}>
            
            <View style = {styles.prodNameQtyView}>
                <View style = {styles.prodNameQty}>
                    <TextInput
                    editable = {enableInput}
                    selectTextOnFocus={true}
                    placeholder='Product Name/Barcode'
                    style = {styles.NameBarcode}
                    value = {nameText}
                    onChangeText = {e=>productSearch(e)}
                    />
                    <TextInput
                    editable = {enableInput}
                    selectTextOnFocus={false}
                    onChangeText = {e=>calTotalQty(e)}
                    value = {qtyText}
                    keyboardType = 'number-pad'
                    placeholder='Quantity'
                    style = {styles.Quantity}
                    />
                </View>
            </View>
           
            {showFlatlist ? (
        <FlatList
        style = {styles.flatlist}
        data = {prodNameList}
        renderItem= {renderItem}
        keyExtractor= {item => item.id}
        />
        ) :(
        <View style = {styles.qtySuggCpspView}> 
                <View style = {styles.qtySuggestions}>
                
                <Buttons 
                    Press = {getQty.bind(this,qtySuggValues[0])} 
                    longPress = {getQty.bind(this,"0.2500000")}
                    textStyle = {styles.buttonTextQty}
                    >
                    {qtySuggValues[0]+prod_unit}
                </Buttons>
                
                <Buttons 
                    Press = {getQty.bind(this,qtySuggValues[1])}
                    textStyle = {styles.buttonTextQty}
                    >
                    {qtySuggValues[1]+prod_unit}
                </Buttons>

                <Buttons 
                    Press = {getQty.bind(this,qtySuggValues[2])}
                    textStyle = {styles.buttonTextQty}
                    >
                    {qtySuggValues[2]+prod_unit}
                </Buttons>

                <Buttons 
                    Press = {getQty.bind(this,qtySuggValues[3])}
                    textStyle = {styles.buttonTextQty}
                    >
                   {qtySuggValues[3]+prod_unit}
                </Buttons>
            </View>

            <View style = {styles.lastRow}>
                
                <TextInput
                editable = {enableInput}
                selectTextOnFocus={false}
                style = {styles.CPSP}
                onChangeText = {e=>calTotalSp(e)}
                keyboardType = 'number-pad'
                placeholder='SP'
                value = {spText}
                />
                
                <Text style = {styles.buttonTextTotal}>{Total}</Text>
                
                <Buttons
               // Press = {goBack}
                buttonStyle = {styles.EnterBtn}
                textStyle   = {styles.Entertext}
                >
                    Enter
                </Buttons>
            
            </View>
        </View>
        
        )
    }


        </View>
    )}

const styles = StyleSheet.create({

entryScreen : {
    flex: 1,
    width : "100%",
    maxHeight : '90%',
    //backgroundColor : 'yellow'
},
prodNameQtyView : {
    flex : 1,
    width : '100%',
    maxHeight : '10%',
},
prodNameQty : {
    flex : 1,
    alignItems:'center',
    justifyContent : 'space-around',
    flexDirection : 'row',
    width : '100%',
    marginHorizontal : 15,
    //backgroundColor : 'pink',
},
qtySuggCpspView : {
    flex : 1 ,
    maxHeight : '25%',
    //backgroundColor : 'blue',
    marginHorizontal : 5,
    marginTop : 5
},
qtySuggestions : {
    flex : 1,
    alignItems:'center',
    justifyContent : 'space-around',
    flexDirection : 'row',
    width : '100%',
    maxHeight : '40%',
    paddingHorizontal : 5,
    //backgroundColor : 'orange',
},
lastRow:{
    flex : 1,
    alignItems:'center',
    justifyContent : 'space-around',
    flexDirection : 'row',
    width : '100%',
    maxHeight : '50%',
    marginTop : 5,
    //backgroundColor : 'pink'
},
NameBarcode : {
    fontSize : 22,
    borderWidth:1,
    paddingLeft : 5,
    height : '90%',
    width : '67%', 
    borderRadius : 5,
    borderColor : 'black',
    marginLeft : 2
},
Quantity : {
    fontSize : 20,
    borderWidth:1,
    paddingLeft : 10,
    height : '90%',
    width : '30%', 
    borderRadius : 5,
    borderColor : 'black',
    marginRight : 2
},
buttonTextQty : {
    fontSize : 18,
    paddingVertical : 5,
    paddingHorizontal : 0,
    fontWeight : 'bold'
},
buttonTextTotal : {
    fontSize : 22,
    fontWeight : 'bold',
    borderWidth : 1,
    borderColor : 'black',
    paddingHorizontal : 25,
    paddingVertical : 10
},
CPSP : {
    fontSize : 20,
    paddingHorizontal : 20,
    paddingVertical : 10,
    borderColor : 'black',
    borderWidth : 1
},
flatlist:{
    width: "100%",
    height : "40%",
    marginVertical : 10,
    marginHorizontal: 50,
    //backgroundColor : 'blue'
  },
item: {
    backgroundColor: '#f9c2ff',
    paddingVertical: 20,
    paddingHorizontal : 10,
    marginVertical: 8,
    borderRadius: 10,
},
title: {
    fontSize : 16,
    fontWeight : 'bold',
    width : '100%',
},
EnterBtn : {
    justifyContent : 'center',
    paddingHorizontal : 10,
    backgroundColor : '#84DFE8'
},
Entertext : {
    fontSize : 20,
    padding : '2%',
    fontWeight : 'bold',
    color : '#4F0500'

},
})

export default ProductEntry;