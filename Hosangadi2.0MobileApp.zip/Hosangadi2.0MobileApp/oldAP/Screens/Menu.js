import React from 'react';
import {View, Text, StyleSheet} from 'react-native'
import Card from '../Components/Card';
import { fetchName} from '../store/actions/getData'
import {  useDispatch} from "react-redux";





const Menu = props => {
    const dispatch = useDispatch();
    dispatch(fetchName())
    return(
        <View>
            <Card 
                title = "Sales Bill"
                onViewDetail = {()=>props.navigation.navigate('SalesBill')} 
                />
        </View>
    )
}



export default Menu;