import React,{ useState,useEffect } from 'react';
import {Alert,BackHandler , StyleSheet} from 'react-native'
import CustomerName from '../Components/CustomerName';

const SalesBill = props => {
  const [change,setChange] = useState(true)
 
  const clearAll = () => {
    BackHandler.exitApp()
  }
  const backAction = () => {
    Alert.alert("Hold on!", "Are you sure you want to go back?", [
      {
        text: "Cancel",
        onPress: () => null,
        style: "cancel"
      },
      { text: "YES", onPress:  clearAll }
    ]);
    return true;
  };

  useEffect(() => {
    BackHandler.addEventListener("hardwareBackPress", backAction);
    return () =>
      BackHandler.removeEventListener("hardwareBackPress", backAction);
  }, [change]);
  //BackHandler.removeEventListener("hardwareBackPress", backAction);
    return( 
      <CustomerName navigate = {props.navigation}/>
    )     
}

const styles = StyleSheet.create({
    screen : {
      flex : 1,
        backgroundColor : 'indigo',
        height:'100%',
        alignItems: 'center',
        margin : 50,
    },
    cutomerDetails : {
        height : '10%',
        padding:5,
        marginTop : 20,
        alignContent: 'center',
        alignItems: 'center',
        width: '70%',
        backgroundColor : 'orange',
        shadowColor : 'black',
        shadowOffset : {width: 0 ,height :2},
        shadowOpacity : 0.26,
        shadowRadius: 8,
        elevation : 5,
        borderRadius :10,
    },
    customerName : {
        paddingLeft : 10,
        width :'100%',
        height:'100%',
        borderColor : 'black',
        borderWidth : 1,
        fontSize : 20,
        borderRadius :10,
    },
    item: {
        backgroundColor: '#f9c2ff',
        padding: 20,
       
        marginVertical: 8,
        marginHorizontal: 0,
      },
      title: {
        fontSize: 16,
      },
      flatlist:{
        width: "80%",
      }
})

export default SalesBill;