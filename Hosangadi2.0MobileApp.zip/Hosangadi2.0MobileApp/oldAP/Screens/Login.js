import React, { useEffect, useState } from 'react';
import { ActivityIndicator, TextInput, Button, Text, View,StyleSheet } from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';

const Login = props => { 
    const [year,setYear] = useState()
    const [statusMessage, setStatusMessage] = useState('')
    const [isLoading, setLoading] = useState(false);
    //const [correctPassword, setCorrectPassword] = useState(false);
    const [userName, setUserName] = useState();
    const [password , setPassword] = useState('')
    const [data, setData] = useState();

    const getDbYear = () => {
      let today = new Date();
      let mm = today.getMonth() + 1;
      let yyyy = String(today.getFullYear()).slice(2);
  
      if (mm<4){
        setYear( parseInt(yyyy)-1 + '-' + yyyy)
      }
      else{
        setYear(yyyy + '-' + parseInt(yyyy)+1)
      }
    }
    
    const getUserNames = async () => {
       try {
        const response = await fetch('http://192.168.1.34:6000/onlySql?sql= SELECT user_id,user_name FROM somanath.users;');
        const json = await response.text();
        setData(JSON.parse(json));
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }
  
    const validate = ()=>{
        if(userName == undefined){
          setStatusMessage("Select UserName :)")
          //setCorrectPassword(true)
          return  true
        }
        else if(password.length < 4 ||password == undefined){
          setStatusMessage("Enter Complete Password :)")
          //setCorrectPassword(true)
          return true
        }
        return false
     }
    
    const authorise = async () => {
       let control = await validate()
       if (control === false){
        let control1 = false
        try {
          const response = await fetch(`http://192.168.1.34:5000/login?user_name=${userName}&user_pass=${password}&year=${year}&server=192.168.1.34`);
          const json = await response.text();//send empty array string '[]'

          if ( json.localeCompare('[]') === 0 ) {
            setStatusMessage("Wrong Password :( Try Again!")
          }
          else if (response.status == 102){
            setStatusMessage("This User has logged in already :O)")
          }
          else if (response.status == 200){
            setStatusMessage("Login Successfull :)")
            control1 = true
          }
          else{
            setStatusMessage("Wrong Password :( Try Again!")
          }
        } catch (error) {
          setStatusMessage("Error"+String(error).split(":").pop()+" :(")
        } finally {
          setPassword('')
          if (control1 === true){
            control1 = false
            setStatusMessage('')
            props.navigation.navigate('Menu')
            }
        }
     }
    
      
    }

    useEffect(() => {
      getUserNames();
      getDbYear();
    }, []);
    
  
    return (
      
      <View style={styles.container}>
  
        {isLoading ? <ActivityIndicator/> : (
          <View>
          
            <View style={styles.textTextField}>
              <Text style={styles.BoldText}> UserName :</Text>
              <Dropdown
                style={styles.enteyField}
                placeholderStyle={styles.placeholderStyle}
                selectedTextStyle={styles.selectedTextStyle}
                iconStyle={styles.iconStyle}
                data={data}
                maxHeight={100}
                labelField="user_name"
                valueField="user_id"
                //placeholder="Select UserName"
                value={userName}
                activeColor = 'green'
                
                onChange={item => {
                  setUserName(item.user_name);
                }}
              />
            </View>
           
            <View style = {styles.textTextField}>
              <Text style = {styles.BoldText}>Password :</Text>
              <TextInput 
                style = {styles.enteyField} 
                placeholder='Enter Password'
                value={password}
                onChangeText = {(text)=>setPassword(text)}
                keyboardType = 'number-pad'
                secureTextEntry={true}
              />
            </View>
    
          </View>
        )}
        
  
        <View style = {styles.buttonLogin}>
          <Button 
                onPress={authorise}
                //onPress={()=>props.navigation.navigate('Menu')}
                title="Login"
                color= "#841584"
                />
        </View>
  
        <View>
            <Text style = {styles.BoldText}>{statusMessage}</Text>
        </View>
         
          
       
        
      </View>
    );
  

}

const styles = StyleSheet.create({
  
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center', 
    
  },

  enteyField: {
    height: 75,
    width : "60%",
    borderBottomColor: 'gray',
    borderWidth: 1,
    paddingLeft : 10,
    marginBottom : 10,
    marginHorizontal : 10,
    fontSize : 16
  },

  placeholderStyle: {
    fontSize: 15,
  },

  selectedTextStyle: {
    fontSize: 20,
  },

  textTextField:{
    width: "100%",
    flexDirection : 'row',
    justifyContent : 'flex-end',
    alignItems : 'center',
  },

  BoldText: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10
  },

  buttonLogin:{
    alignItems:'center',
    minHeight : 40,
    width : '70%',
    marginTop : 35
  },

});

export default Login;