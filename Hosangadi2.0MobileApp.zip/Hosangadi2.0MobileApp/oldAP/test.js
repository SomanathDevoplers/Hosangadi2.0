x= '00.4'
console.log(parseInt(x));