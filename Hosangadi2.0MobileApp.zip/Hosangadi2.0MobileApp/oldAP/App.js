import React from 'react';
import MainNavigator from './Navigations/Navigation'
import { createStore , combineReducers , applyMiddleware, compose} from 'redux'
import getData from './store/reducers/getData';
import { Provider } from 'react-redux'
import thunkMiddleware from 'redux-thunk'

const rootReducer = combineReducers({
  customerName : getData,
})
//const middlewareEnhancer = applyMiddleware( thunkMiddleware)
//const composedEnhancers = compose(middlewareEnhancer)

const store = createStore(rootReducer,applyMiddleware(thunkMiddleware))

export default function App() {
  return (
    
    <Provider store={store}>
      <MainNavigator/>
    </Provider>
      
  );
}

