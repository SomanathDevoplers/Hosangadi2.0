from requests import get 

req = get("http://localhost:7000/billOnly", params = {'billNumber':'18158','dbYear':'21'})
print(req)